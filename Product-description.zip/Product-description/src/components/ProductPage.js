import React, { Component } from "react";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import "./ProductPage.css";

import * as userActions from "../actionCreators/products";

class ProductPage extends Component {
  componentDidMount() {
    const products = {
      "products": [        
        {
          "_id": "5aaba1c149f935fffa80526c",
          "productId": 1,
          "ProductName": "Wrist Watch",
          "productDesc": "A watch is a timepiece intended to be carried or worn by a person. It is designed to keep working despite the motions caused by the person's activities.A wristwatch is designed to be worn around the wrist, attached by a watch strap or other type of bracelet.",
          "productPrice": "1,545",
          "productImage": "https://media.istockphoto.com/photos/wristwatch-picture-id628348700",
          "productSize": [
            "S",
            "M",
            "L",
            "XL"
          ],
          "productColor": [
            "#8c137e",
            "#915e11",
            "#231782"
          ],
          "reviewStatus": {
            "reviewCount": 4,
            "starRate": 2.75
          }
        },
        {
          "_id": "5aaba1d749f935fffa805275",
          "productId": 2,
          "ProductName": "Mobile Phone",
          "productDesc": "A mobile phone is a wireless handheld device that allows users to make calls and send text messages, among other features. The earliest generation of mobile phones could only make and receive calls.",
          "productPrice": "15,545",
          "productImage": "https://sc01.alicdn.com/kf/HTB10nCBSVXXXXbCXVXXq6xXFXXXD/Best-Mini-Small-Size-Mobile-Phone-Dual.jpg_350x350.jpg",
          "productSize": [
            "S",
            "M",
            "L"
          ],
          "productColor": [
            "#7d8e70",
            "#15061c",
            "#d1ceba"
          ],
          "reviewStatus": {
            "reviewCount": 4,
            "starRate": 3.375
          }
        },
        {
          "_id": "5aaba20b49f935fffa80527f",
          "productId": 4,
          "ProductName": "Memory Drive",
          "productDesc": "A Memory Stick is a type of portable flash memory storage appliance that's typically used with handheld devices. Memory Sticks were first introduced by Sony in their cameras, camcorders and other digital photography equipment.",
          "productPrice": "745",
          "productImage": "https://images-na.ssl-images-amazon.com/images/I/41Y1NCqOiGL.jpg",
          "productSize": [
            "S",
            "M",
            "L"
          ],
          "productColor": [
            "#7d8e70",
            "#15061c",
            "#d1ceba"
          ],
          "reviewStatus": {
            "reviewCount": 0,
            "starRate": 0
          }
        },
        {
          "_id": "5aaba1c149f935fffa80526w",
          "productId": 3,
          "ProductName": "Pendrive",
          "productDesc": "USB flash drives use the USB mass storage device class standard, supported natively by modern operating systems such as Windows, Linux, macOS and other Unix-like systems, as well as many BIOS boot ROMs. USB drives with USB 2.0 support can store more data and transfer faster than much larger optical disc drives ",
          "productPrice": "1,245",
          "productImage": "https://images-eu.ssl-images-amazon.com/images/I/31HLNKwtjAL._AC_US160_.jpg",
          "productSize": [
            "S",
            "M",
            "L",
            "XL"
          ],
          "productColor": [
            "#8c137e",
            "#915e11",
            "#231782"
          ],
          "reviewStatus": {
            "reviewCount": 4,
            "starRate": 2.75
          }
        }
      ]
    }
    this.props.actions.getProductsSuccess(products);
  }
  openDetailsOverlay(index) {
    this.props.actions.setDetails(index);
  }
  render() {
    const { productCard, detailsIndex } = this.props.products;
    const { products } = productCard;
    let prodArr = [];
    if (productCard && productCard.products && productCard.products.length > 0) {
      prodArr = productCard.products;
    }
    return <div className="container">
   <hr/>
    <h1 className= "header" > <strong> HEADER </strong></h1>
    <hr/>
      <div className="card">
        <div className="container-fliud">
          <div className="wrapper row">
            <div className="preview col-md-6">
              <div className="preview-pic tab-content">
                <div className="tab-pane active" id={"pic-"+detailsIndex}><img alt={detailsIndex} src={products && products[detailsIndex].productImage} /></div>
              </div>
              <ul className="preview-thumbnail nav nav-tabs">
                {prodArr.map((item, index) => <li onClick={() => this.openDetailsOverlay(index)} key={index}><a data-target={"#pic-" + index}  data-toggle="tab"><img alt={index} src={item.productImage} style={{
                  'width': '100px', 'height': '100px'
                }} /></a></li>)}
              </ul>
            </div>
            <div className="details col-md-6 " >
              <h3 className="product-title">{products && products[detailsIndex].ProductName}</h3>
              <p className="product-description">{products && products[detailsIndex].productDesc}</p>
              <h4><strong> ₹ <span>{products && products[detailsIndex].productPrice}</span></strong></h4><br/>
              <div className="action">
                <button className="add-to-cart btn btn-default" type="button">add to cart</button>
              </div>
            </div>
          </div>
        </div>
      </div>
      <hr/>
    <h1 className= "footer" > <strong> FOOTER </strong> </h1>
    <hr/>
    </div>

  }
}

function mapStateToProps(state) {
  return {
    products: state.products
  };
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(userActions, dispatch)
  };
}


export default connect(mapStateToProps, mapDispatchToProps)(ProductPage);

